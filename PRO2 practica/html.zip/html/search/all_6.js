var searchData=
[
  ['jg',['jg',['../class_jugador.html#a53ac73c3dc720ca6e66406b309077472',1,'Jugador']]],
  ['jp',['jp',['../class_jugador.html#a306eb04292a1aa300a39c2464c1368fd',1,'Jugador']]],
  ['jugador',['Jugador',['../class_jugador.html',1,'Jugador'],['../class_jugador.html#a232c46f75691af6210096e5972535d71',1,'Jugador::Jugador()']]],
  ['jugador_2ecc',['Jugador.cc',['../_jugador_8cc.html',1,'']]],
  ['jugador_2ehh',['Jugador.hh',['../_jugador_8hh.html',1,'']]],
  ['jugadores',['jugadores',['../class_cjt__jugadores.html#ae3fc5f98e0f343b039bd7dff0e616ecc',1,'Cjt_jugadores']]]
];
