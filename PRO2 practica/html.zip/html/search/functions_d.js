var searchData=
[
  ['torneo',['Torneo',['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo']]],
  ['torneo_5fdisputado',['torneo_disputado',['../class_jugador.html#a5e1cd15a764a285556e35257209a2c8c',1,'Jugador']]]
];
