var searchData=
[
  ['sg',['sg',['../class_jugador.html#a678970fa93782e3e68f939c37fff5030',1,'Jugador']]],
  ['sp',['sp',['../class_jugador.html#a5bed10a21acb0c437828df282050b2ab',1,'Jugador']]]
];
