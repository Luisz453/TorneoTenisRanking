var searchData=
[
  ['info_5franking',['info_ranking',['../struct_cjt__jugadores_1_1info__ranking.html',1,'Cjt_jugadores']]]
];
