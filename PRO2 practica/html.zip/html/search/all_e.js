var searchData=
[
  ['tabla',['tabla',['../class_cjt__categorias.html#af03722d79d2b1ec784954dd13a7168eb',1,'Cjt_categorias']]],
  ['torneo',['Torneo',['../class_torneo.html',1,'Torneo'],['../class_torneo.html#a7bf6d35a7ec8d0e13a0bed8deb8add3e',1,'Torneo::Torneo()']]],
  ['torneo_2ecc',['Torneo.cc',['../_torneo_8cc.html',1,'']]],
  ['torneo_2ehh',['Torneo.hh',['../_torneo_8hh.html',1,'']]],
  ['torneo_5fdisputado',['torneo_disputado',['../class_jugador.html#a5e1cd15a764a285556e35257209a2c8c',1,'Jugador']]],
  ['torneos',['torneos',['../class_jugador.html#a2c4256c69ddf76e1c4f1e48f56ed305c',1,'Jugador']]]
];
