var searchData=
[
  ['finalizar_5ftorneo',['finalizar_torneo',['../class_cjt__torneos.html#adba857b43ab1282910fe1567dde5839f',1,'Cjt_torneos']]]
];
