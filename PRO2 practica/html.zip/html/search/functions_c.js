var searchData=
[
  ['sumar_5fpuntos',['sumar_puntos',['../class_torneo.html#af3d9ca7a6edf9bbf20a2af3b60bf23fc',1,'Torneo']]],
  ['sumar_5fpuntos_5ftorneo',['sumar_puntos_torneo',['../class_cjt__jugadores.html#adaead4375a0c4e8cb02782988423e1d8',1,'Cjt_jugadores']]]
];
