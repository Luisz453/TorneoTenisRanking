var searchData=
[
  ['ranking',['ranking',['../class_cjt__jugadores.html#a2a64dd6a0c9315af038dfdb4c27da059',1,'Cjt_jugadores']]]
];
