var searchData=
[
  ['categoria',['categoria',['../class_torneo.html#ad9bec7ef311a416138abb99f3a487b3e',1,'Torneo']]],
  ['ct',['ct',['../class_cjt__torneos.html#a701df4fc4fbd2d6ffa081a01845083f3',1,'Cjt_torneos']]]
];
