var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['modificar_5finscritos',['modificar_inscritos',['../class_torneo.html#a89490159cb29ce076f955ebd1ef3a3bf',1,'Torneo']]],
  ['modificar_5fpos',['modificar_pos',['../class_jugador.html#af77bc217af6013d9e57cab34dd03921c',1,'Jugador']]]
];
