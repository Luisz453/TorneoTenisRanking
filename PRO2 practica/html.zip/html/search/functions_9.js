var searchData=
[
  ['nuevo_5fjugador',['nuevo_jugador',['../class_cjt__jugadores.html#a23468af9b07a692a3036a1bf5a128232',1,'Cjt_jugadores']]],
  ['nuevo_5ftorneo',['nuevo_torneo',['../class_cjt__torneos.html#a7385438366fe4d50e6cf82aa6c381c08',1,'Cjt_torneos']]],
  ['num_5fcategorias',['num_categorias',['../class_cjt__categorias.html#a8d99bf913eb3aaf562e5a086faaae517',1,'Cjt_categorias']]],
  ['num_5fjugadores',['num_jugadores',['../class_cjt__jugadores.html#a4951d7691e67c44415fdcb3119dd4148',1,'Cjt_jugadores']]],
  ['num_5ftorneos',['num_torneos',['../class_cjt__torneos.html#aba6d57df308bdbfa173578c108e19b82',1,'Cjt_torneos']]]
];
