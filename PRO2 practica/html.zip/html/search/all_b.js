var searchData=
[
  ['pg',['pg',['../class_jugador.html#ab254a72417747985ffaf53b0508e5e31',1,'Jugador']]],
  ['pos_5fanterior',['pos_anterior',['../struct_cjt__jugadores_1_1info__ranking.html#a94cae50fbd756efb92e76e6f9cc396ce',1,'Cjt_jugadores::info_ranking']]],
  ['pos_5franking',['pos_ranking',['../class_jugador.html#a200ee7c036d98654af6fab08b8b909e9',1,'Jugador']]],
  ['pp',['pp',['../class_jugador.html#a90af14828909d3c5cd3fb4a285e96daf',1,'Jugador']]],
  ['program_2ecc',['program.cc',['../program_8cc.html',1,'']]],
  ['puntos',['puntos',['../struct_cjt__jugadores_1_1info__ranking.html#a9548a26f4ce9f133898897695cf0469f',1,'Cjt_jugadores::info_ranking']]]
];
