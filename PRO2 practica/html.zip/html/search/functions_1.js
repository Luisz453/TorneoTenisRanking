var searchData=
[
  ['categoria_5fnombre',['categoria_nombre',['../class_cjt__categorias.html#a1b0f9a447879796a42ee0dac753f8779',1,'Cjt_categorias']]],
  ['cjt_5fcategorias',['Cjt_categorias',['../class_cjt__categorias.html#acb1bba449ac618047f1ac5f9f7756ec1',1,'Cjt_categorias']]],
  ['cjt_5fjugadores',['Cjt_jugadores',['../class_cjt__jugadores.html#af40661f610000ab6febf3ea0de7a451b',1,'Cjt_jugadores']]],
  ['cjt_5ftorneos',['Cjt_torneos',['../class_cjt__torneos.html#acc82582b779afd52bbb92c8094d473ac',1,'Cjt_torneos']]],
  ['consultar_5fcategoria',['consultar_categoria',['../class_torneo.html#ac558198d579c88ab11b873ed3cf0953d',1,'Torneo']]],
  ['consultar_5fnombre_5franking',['consultar_nombre_ranking',['../class_cjt__jugadores.html#ad8d836a5be49a639ffed71a643080d53',1,'Cjt_jugadores']]],
  ['consultar_5fpos',['consultar_pos',['../class_jugador.html#a69ab40db4a82c1b656895631b9949cbc',1,'Jugador']]],
  ['crear_5fcuadro_5femparejamientos',['crear_cuadro_emparejamientos',['../class_torneo.html#afbbadc7c5829d021921caf2ae9a2d2ee',1,'Torneo']]],
  ['criterio',['criterio',['../class_cjt__jugadores.html#a9aff76f40c40d4856649fa97330fd0d0',1,'Cjt_jugadores']]],
  ['cuadro_5fresultados',['cuadro_resultados',['../class_torneo.html#a64eda02f7720674f1808521d5547c02a',1,'Torneo']]]
];
