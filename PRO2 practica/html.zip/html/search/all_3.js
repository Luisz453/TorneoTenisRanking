var searchData=
[
  ['eliminar_5fjugador',['eliminar_jugador',['../class_cjt__jugadores.html#ab0bba7a90bea0c07c219531985746bcb',1,'Cjt_jugadores']]],
  ['eliminar_5ftorneo',['eliminar_torneo',['../class_cjt__torneos.html#abcf5af8c44e1a82fec482aa1a0abacb2',1,'Cjt_torneos']]],
  ['emparejamientos',['emparejamientos',['../class_torneo.html#a18e1c1f6f9f658bc2c2390d3e2a9a853',1,'Torneo']]],
  ['escriure_5femparejamientos',['escriure_emparejamientos',['../class_torneo.html#ada7981ac531bf186fa6df689620574cc',1,'Torneo']]],
  ['estadisticas_5fjugador',['estadisticas_jugador',['../class_cjt__jugadores.html#a4c2e7064b8c6f2647dfb086c6d161bfd',1,'Cjt_jugadores']]],
  ['existe',['existe',['../class_cjt__jugadores.html#abc6937363d137e38ab7545c5f6ec7f10',1,'Cjt_jugadores::existe()'],['../class_cjt__torneos.html#ab7cf8c8a93172e3097e3e40c9bc55255',1,'Cjt_torneos::existe()']]]
];
