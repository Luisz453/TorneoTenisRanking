var searchData=
[
  ['datos_5fpartido',['datos_partido',['../class_jugador.html#a241e7729a48da6c6d94ef51326a45a18',1,'Jugador']]]
];
