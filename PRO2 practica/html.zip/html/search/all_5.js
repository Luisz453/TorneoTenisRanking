var searchData=
[
  ['imprime_5fcuadro_5femparejamientos',['imprime_cuadro_emparejamientos',['../class_torneo.html#adc22cda8d641ed9130e1171c4f8d5b84',1,'Torneo']]],
  ['imprime_5fcuadro_5fresultados',['imprime_cuadro_resultados',['../class_torneo.html#aa42b2460bffdc5e1e85f7ebff4a5a6d0',1,'Torneo']]],
  ['imprimir_5fcategorias',['imprimir_categorias',['../class_cjt__categorias.html#acd18a2fe2b4336dd5faa7e418962d713',1,'Cjt_categorias']]],
  ['imprimir_5flista_5fjugadores',['imprimir_lista_jugadores',['../class_cjt__jugadores.html#aeeb65f2beec6cac01abf0135b37dd104',1,'Cjt_jugadores']]],
  ['imprimir_5flista_5fpuntos',['imprimir_lista_puntos',['../class_torneo.html#ae5ed31026d55786a078666e4a7d4d62e',1,'Torneo']]],
  ['imprimir_5flista_5ftorneos',['imprimir_lista_torneos',['../class_cjt__torneos.html#a29ca3cb4f9fd9f5924b07add78601f40',1,'Cjt_torneos']]],
  ['imprimir_5franking',['imprimir_ranking',['../class_cjt__jugadores.html#a2eca08ea3674049547e6eb6242da1df5',1,'Cjt_jugadores']]],
  ['imprimir_5fstats',['imprimir_stats',['../class_jugador.html#a8bd81b77ba3d2e46bee69ea2f628f00d',1,'Jugador']]],
  ['info_5franking',['info_ranking',['../struct_cjt__jugadores_1_1info__ranking.html',1,'Cjt_jugadores']]],
  ['inicializar_5fins_5factuales',['inicializar_ins_actuales',['../class_torneo.html#a0d4f0e3c6128b5ca07dc74e88daf4da7',1,'Torneo']]],
  ['iniciar_5ftorneo',['iniciar_torneo',['../class_cjt__torneos.html#aa6ca6587e715b38907a0af67f0e13da4',1,'Cjt_torneos']]],
  ['ins_5factuales',['ins_actuales',['../class_torneo.html#a2293acd2d9d04bdefc603ab4cdce2c5a',1,'Torneo']]],
  ['ins_5fanterior',['ins_anterior',['../class_torneo.html#ad31e1a620a859ac6066eb6ca9de61e61',1,'Torneo']]]
];
