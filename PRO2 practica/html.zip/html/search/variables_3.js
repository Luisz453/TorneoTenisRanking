var searchData=
[
  ['jg',['jg',['../class_jugador.html#a53ac73c3dc720ca6e66406b309077472',1,'Jugador']]],
  ['jp',['jp',['../class_jugador.html#a306eb04292a1aa300a39c2464c1368fd',1,'Jugador']]],
  ['jugadores',['jugadores',['../class_cjt__jugadores.html#ae3fc5f98e0f343b039bd7dff0e616ecc',1,'Cjt_jugadores']]]
];
