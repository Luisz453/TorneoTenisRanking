var searchData=
[
  ['ins_5factuales',['ins_actuales',['../class_torneo.html#a2293acd2d9d04bdefc603ab4cdce2c5a',1,'Torneo']]],
  ['ins_5fanterior',['ins_anterior',['../class_torneo.html#ad31e1a620a859ac6066eb6ca9de61e61',1,'Torneo']]]
];
