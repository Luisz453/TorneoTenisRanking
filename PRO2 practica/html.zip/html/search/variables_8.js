var searchData=
[
  ['tabla',['tabla',['../class_cjt__categorias.html#af03722d79d2b1ec784954dd13a7168eb',1,'Cjt_categorias']]],
  ['torneos',['torneos',['../class_jugador.html#a2c4256c69ddf76e1c4f1e48f56ed305c',1,'Jugador']]]
];
