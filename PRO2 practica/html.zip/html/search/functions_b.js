var searchData=
[
  ['restar_5fpuntos',['restar_puntos',['../class_cjt__jugadores.html#a1940533810f2ea0b82c9a409b9ce6fab',1,'Cjt_jugadores']]],
  ['resultado',['resultado',['../class_torneo.html#ad3d497cf4a6eafce2c36160f464bbe03',1,'Torneo']]],
  ['resultado_5fpartido',['resultado_partido',['../class_cjt__jugadores.html#a843a0aa4f91b785797a5023c23766bf9',1,'Cjt_jugadores']]],
  ['resultados_5ftorneo',['resultados_torneo',['../class_torneo.html#a791793b8131e964b1387b84f849ae2cd',1,'Torneo']]]
];
