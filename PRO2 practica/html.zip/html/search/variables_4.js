var searchData=
[
  ['nc',['nc',['../class_cjt__categorias.html#aad3febb4a17038ba65b2f79a4a509289',1,'Cjt_categorias']]],
  ['nombre',['nombre',['../struct_cjt__jugadores_1_1info__ranking.html#a9f0be0dd186ae9693b9b83e316adb1e3',1,'Cjt_jugadores::info_ranking']]]
];
