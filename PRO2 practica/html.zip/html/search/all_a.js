var searchData=
[
  ['obtencion_5fpuntos',['obtencion_puntos',['../class_torneo.html#a5ee0c8ca296bf422d040b05c768f7ba0',1,'Torneo']]],
  ['obtener_5fpuntos',['obtener_puntos',['../class_cjt__categorias.html#abddf6d1471987a718e12485f58b95c1b',1,'Cjt_categorias']]],
  ['ordenar_5franking',['ordenar_ranking',['../class_cjt__jugadores.html#a61d4c0806dcd9973fe8da0af7d39d672',1,'Cjt_jugadores']]]
];
