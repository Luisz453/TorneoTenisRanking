var searchData=
[
  ['emparejamientos',['emparejamientos',['../class_torneo.html#a18e1c1f6f9f658bc2c2390d3e2a9a853',1,'Torneo']]]
];
