var searchData=
[
  ['leer',['leer',['../class_cjt__categorias.html#a25f0264b46b1c1de5af074bfae1ee5ed',1,'Cjt_categorias::leer()'],['../class_cjt__jugadores.html#a625e1ba48fc2f9b7c868820e1dc417f1',1,'Cjt_jugadores::leer()'],['../class_cjt__torneos.html#af0f18e3971687674b58d020689fa2203',1,'Cjt_torneos::leer()']]],
  ['leer_5femparejamientos',['leer_emparejamientos',['../class_torneo.html#ae4d0e16d82621a4f5e16fcec74ccdcba',1,'Torneo']]],
  ['lista_5finscritos',['lista_inscritos',['../class_cjt__torneos.html#a6acf54664dd8dd524d9f9671e83b181b',1,'Cjt_torneos']]]
];
