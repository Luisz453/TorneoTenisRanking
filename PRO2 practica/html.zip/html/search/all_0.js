var searchData=
[
  ['actualizar',['actualizar',['../class_torneo.html#a817ee4377de539e5292eb1491d2f9b29',1,'Torneo']]],
  ['actualizar_5fpos',['actualizar_pos',['../class_cjt__jugadores.html#ac221d0fd27654e48e2c27560562a7d5a',1,'Cjt_jugadores']]],
  ['anadir_5fcategoria',['anadir_categoria',['../class_torneo.html#a089468654daf52979cd7c393c51ceb85',1,'Torneo']]]
];
